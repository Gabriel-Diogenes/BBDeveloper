package br.com.intercomex.api_BBDeveloper.BBDeveloper.util;

import java.util.UUID;

/**
 * Utilitário para operações relacionadas a Pix.
 */
public class PixUtil {

    /**
     * Gera um TXID único para cobrança Pix.
     * 
     * Remove hífens do UUID para formato esperado pelo BB.
     * 
     * @return TXID formatado (32 caracteres hexadecimais)
     */
    public static String gerarTxid() {
        return UUID.randomUUID()
                .toString()
                .replace("-", "");
    }
}
