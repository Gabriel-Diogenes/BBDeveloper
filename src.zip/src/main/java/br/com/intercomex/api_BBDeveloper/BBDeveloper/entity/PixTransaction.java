package br.com.intercomex.api_BBDeveloper.BBDeveloper.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Entidade de Transação Pix.
 * 
 * Preparatória para persistência futura em banco de dados.
 * Será mapeada com Spring Data JPA quando persistência for necessária.
 * 
 * Atualmente mantida em memória, pronta para evolução.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PixTransaction {

    private String txid;
    private String status;
    private String chave;
    private String valor;
    private LocalDateTime dataCriacao;
    private LocalDateTime dataAtualizacao;
    private String pixCopiaECola;
}
