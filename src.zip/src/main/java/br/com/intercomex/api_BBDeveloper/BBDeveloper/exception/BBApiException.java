package br.com.intercomex.api_BBDeveloper.BBDeveloper.exception;

/**
 * Exceção de erro na integração com BB Developer API.
 * 
 * Lançada quando há falha em chamadas à API do Banco do Brasil.
 */
public class BBApiException extends RuntimeException {

    public BBApiException(String message) {
        super(message);
    }

    public BBApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
