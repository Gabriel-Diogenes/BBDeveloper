package br.com.intercomex.api_BBDeveloper.BBDeveloper.controller;

import br.com.intercomex.api_BBDeveloper.BBDeveloper.dto.auth.TokenResponseDTO;
import br.com.intercomex.api_BBDeveloper.BBDeveloper.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller de Autenticação.
 * 
 * Responsável por:
 * - Receber requisições HTTP
 * - Validar entrada
 * - Retornar responses
 * 
 * Sem lógica de negócio (delegada ao Service).
 */
@RestController
@RequiredArgsConstructor
public class AuthenticationController {

    private final AuthService authService;

    /**
     * Gera um novo token de acesso.
     * 
     * @return Token de acesso OAuth2.0
     */
    @PostMapping("/token")
    public ResponseEntity<TokenResponseDTO> gerarToken() {
        return ResponseEntity.ok(authService.gerarToken());
    }
}
